import { createDrawerNavigator } from "@react-navigation/drawer"
import { NavigationContainer } from "@react-navigation/native"
import Home from "./components/Home/Home";
import Login from "./components/User/Login";
import Logout from "./components/User/Logout";
import Resgiter from "./components/User/Resgiter";



  const Drawer = createDrawerNavigator();
const App = () => {
  return (
    <NavigationContainer>
        <Drawer.Navigator>
          <Drawer.Screen name ="Home" component={Home} options={{title:'TRANG CHỦ'}}/>
          <Drawer.Screen name ="Login" component={Login} options={{title:'ĐĂNG NHẬP'}}/>
          <Drawer.Screen name ="Logout" component={Logout} options={{title:'ĐĂNG XUẤT'}} />
          <Drawer.Screen name ="Resgiter" component={Resgiter} options={{title:'TRANG ĐĂNG KÝ'}}/>
         
        </Drawer.Navigator>
    </NavigationContainer>
  )
}
  export default App
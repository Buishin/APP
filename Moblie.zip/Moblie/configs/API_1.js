import axios from "axios";

const HOST ='http://127.0.0.1:8000'
export const endpoints = {
    'users': '/users/'
}
export const authApi =() => {
    return axios.create({
        baseURL:HOST,
        Headers: {
            'Authorization': `Bearer...`
        }
    })
}
export default axios.create({
    baseURL:HOST
})
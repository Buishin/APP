import { View,Text, ActivityIndicator} from "react-native"
import MyStyle from "../../Style/MyStyle"
import style from "./style"
import React, { useEffect, useState } from "react"
import { endpoints } from "../../configs/API_1.js"



const Home =() =>{
    
    const [users, setusers] =React.useState(null)

    React.useEffect( () => {
        const loadUsers = async()=>{
            try {
                let res = await API.get(endpoints);
              setusers(res.data.results)

            } catch (error) {
                console.error(ex)
            }
        }
        loadUsers();
    }
    ,[]);

    return(
        <View style={MyStyle.container}>
            <Text style={style.user}>Home</Text>
            {users===null?<ActivityIndicator/>:<>
                    {users.map(c=>{
                        <View key={c.id}>
                            <Text>{c.user}</Text>
                        </View>
                    })}
            </>}
        </View>
    )
}
export default Home
import { StyleSheet } from "react-native";

export default StyleSheet.create({
    user : {
        fontSize: 50,
        color : "blue",
    }
})
import { View,Text } from "react-native"
import MyStyle from "../../Style/MyStyle"

const Login = () => {
    return(
        <View style = {MyStyle.container}>
            <Text>LOGOUT</Text>
            </View>
    )
}
export default Login